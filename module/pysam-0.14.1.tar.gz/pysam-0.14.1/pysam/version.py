# pysam versioning information
__version__ = "0.14.1"

# TODO: upgrade number
__samtools_version__ = "1.7"

# TODO: upgrade code and number
__bcftools_version__ = "1.6"

__htslib_version__ = "1.7"
